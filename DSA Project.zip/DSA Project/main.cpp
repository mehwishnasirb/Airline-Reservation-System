#include <iostream>
#include <fstream>
#include <string>
using namespace std;

// Constants
const int MAX_SEATS = 50;
const int MAX_INPUT = 1000;

// Each constant corresponds to a specific type of seat, such as Economy, Business, or First Class.
enum SeatClass {
    ECONOMY,
    BUSINESS,
    FIRST_CLASS
};
// Node class for the doubly-linked list
class Node
{
public:
    int seatNumber;
    string passengerName;
    SeatClass seatClass;  // Attribute for seat class
    Node* next;
    Node* prev;

    // Constructor
    Node(int seat, const string& name, SeatClass sClass)
        : seatNumber(seat), passengerName(name), seatClass(sClass), next(nullptr), prev(nullptr) {}
};

// Doubly Linked List class for seat storage
class DoubleLinkedList
{
private:
    Node* head;
    Node* tail;

public:
    DoubleLinkedList() : head(nullptr), tail(nullptr) {}

    // Insert a new seat at the beginning of the list
    void insert(int seat, const string& name, SeatClass sClass)
{
    Node* newNode = new Node(seat, name, sClass);

    if (!head)
    {
        head = tail = newNode;
    }
    else
    {
        newNode->next = head;
        head->prev = newNode;
        head = newNode;
    }
}




    // Remove a seat from the list
    void remove(int seat)
    {
        Node* current = head;

        while (current && current->seatNumber != seat)
        {
            current = current->next;
        }

        if (current)
        {
            if (current->prev)
            {
                current->prev->next = current->next;
            }
            else
            {
                head = current->next;
            }

            if (current->next)
            {
                current->next->prev = current->prev;
            }

            if (current == tail)
            {
                tail = current->prev;
            }

            delete current;
        }
    }

    // Display all seats in the list
    void display()
    {
        if (!head)
        {
            cout << "No seats available." << endl;
            return;
        }

        Node* current = head;
        while (current)
        {
            cout << "Seat " << current->seatNumber << ": " << current->passengerName << endl;
            current = current->next;
        }
        cout << endl;
    }

    void displayBookedSeats() const {
    Node* current = head;

    if (!current) {
        cout << "No seats booked." << endl;
        return;
    }

    cout << "Booked Seats:" << endl;

    while (current) {
        cout << "Seat " << current->seatNumber << ": " << current->passengerName << " (Class: ";

        if (current->seatClass == SeatClass::ECONOMY) {
            cout << "Economy";
        } else if (current->seatClass == SeatClass::BUSINESS) {
            cout << "Business";
        } else if (current->seatClass == SeatClass::FIRST_CLASS) {
            cout << "First Class";
        } else {
            cout << "Unknown Class";
        }

        cout << ")" << endl;

        current = current->next;
    }

    cout << endl;
}


    // Get the head of the list
    Node* getHead() const
    {
        return head;
    }
};

// ArrayList class to store seats
class ArrayList
{
private:
    Node* seatArray[MAX_SEATS];
    int size;

public:
    ArrayList() : size(0)
    {
        for (int i = 0; i < MAX_SEATS; ++i)
        {
            seatArray[i] = nullptr;
        }
    }

    // Insert a new seat
    void insert(int seat, const string& name, SeatClass sClass)
    {
        if (size < MAX_SEATS)
        {
            seatArray[size++] = new Node(seat, name, sClass);
        }
        else
        {
            cout << "Cannot insert. Array is full." << endl;
        }
    }

    // Remove a seat from the array
    void remove(int seat)
    {
        for (int i = 0; i < size; ++i)
        {
            if (seatArray[i] && seatArray[i]->seatNumber == seat)
            {
                delete seatArray[i];

                // Shift elements to fill the gap
                for (int j = i; j < size - 1; ++j)
                {
                    seatArray[j] = seatArray[j + 1];
                }

                seatArray[size - 1] = nullptr;
                --size;

                cout << "Seat " << seat << " removed." << endl;
                return;
            }
        }

        cout << "Seat " << seat << " not found." << endl;
    }

    // Display all seats in the array
    void display()
    {
        for (int i = 0; i < size; ++i)
        {
            cout << "Seat " << seatArray[i]->seatNumber << ": " << seatArray[i]->passengerName << endl;
        }
        cout << endl;
    }

    // Get the size of the array
    int getSize() const
    {
        return size;
    }
};

// Queue class for booking requests
class BookingQueue
{
private:
    int queue[MAX_SEATS];
    int front;
    int rear;

public:
    BookingQueue() : front(-1), rear(-1) {}

    // Enqueue a seat number into the queue
    void enqueue(int seat)
    {
        if (rear == MAX_SEATS - 1)
        {
            cout << "Booking queue is full. Cannot enqueue more requests." << endl;
            return;
        }

        if (front == -1)
        {
            front = 0;
        }

        queue[++rear] = seat;
    }

    // Dequeue a seat number from the queue
    int dequeue()
    {
        if (front == -1)
        {
            cout << "Booking queue is empty." << endl;
            return -1;
        }

        int seat = queue[front++];

        if (front > rear)
        {
            front = rear = -1;
        }

        return seat;
    }

    // Get the rear index of the queue
    int getRear() const
    {
        return rear;
    }

    // Check if the queue is empty
    bool isEmpty() const
    {
        return front == -1;
    }

    // Get the front index of the queue
    int getFront() const
    {
        return front;
    }

    // Get a pointer to the queue array
    const int* getQueue() const
    {
        return queue;
    }
};

// Stack class for undo functionality
class UndoStack
{
private:
    int stack[MAX_SEATS];
    int top;

public:
    UndoStack() : top(-1) {}

    // Push a seat number onto the stack
    void push(int seat)
    {
        if (top < MAX_SEATS - 1)
        {
            stack[++top] = seat;
        }
    }

    // Pop a seat number from the stack
    int pop()
    {
        if (top >= 0)
        {
            return stack[top--];
        }

        return -1;
    }

    // Check if the stack is empty
    bool isEmpty() const
    {
        return top == -1;
    }
};

// Airline Reservation System class
class AirlineReservationSystem
{
private:
    DoubleLinkedList seatList;
    BookingQueue bookingQueue;
    UndoStack undoStack;

// Function getSeatClass
SeatClass getSeatClass(int seat) const
    {
        for (const Node* current = seatList.getHead(); current; current = current->next)
        {
            if (current->seatNumber == seat)
            {
                return current->seatClass;
            }
        }

        // If the seat is not found, return a default value
        return SeatClass::ECONOMY; // or return SeatClass::FIRST_CLASS; or return SeatClass::BUSINESS;
    }

public:
    // Display all available seats
    void displayAvailableSeats()
    {
        cout << "Available Seats:" << endl;
        seatList.display();
    }

    // Book a seat with the provided passenger name
    void bookSeat(const string& passengerName)
    {
        int seat = bookingQueue.dequeue();

        if (seat == -1)
        {
            cout << "No booking requests in the queue." << endl;
            return;
        }

        SeatClass seatClass = getSeatClass(seat);

        seatList.insert(seat, passengerName, seatClass);
        undoStack.push(seat);

        cout << "Seat " << seat << " booked for " << passengerName << "." << endl;
    }

    // Undo the last booking
    void undoLastBooking()
    {
        int seat = undoStack.pop();

        if (seat == -1)
        {
            cout << "No booking to undo." << endl;
            return;
        }

        seatList.remove(seat);
        bookingQueue.enqueue(seat);

        cout << "Undo: Booking for seat " << seat << " canceled." << endl;
    }

    // Request a booking for the specified seat
    void requestBooking(int seat)
    {
        if (seat < 1 || seat > MAX_SEATS)
        {
            cout << "Invalid seat number. Please choose a seat between 1 and " << MAX_SEATS << "." << endl;
            return;
        }

        if (!isSeatBooked(seat))
        {
            bookingQueue.enqueue(seat);
            cout << "Booking request for seat " << seat << " added to the queue." << endl;
        }
        else
        {
            cout << "Seat " << seat << " is already booked. Please choose another seat." << endl;
        }
    }

    // Check if a seat is booked
    bool isSeatBooked(int seat) const
    {
        Node* current = seatList.getHead();
        while (current)
        {
            if (current->seatNumber == seat)
            {
                return true; // Seat is booked
            }
            current = current->next;
        }
        return false; // Seat is not booked
    }

    // Cancel Seat
    void cancelBooking(int seat)
    {
        if (isSeatBooked(seat))
        {
            seatList.remove(seat);
            bookingQueue.enqueue(seat);
            undoStack.push(seat);
            cout << "Booking for seat " << seat << " canceled.\n";
        }
        else
        {
            cout << "Seat " << seat << " is not booked. Nothing to cancel.\n";
        }
    }

    // Display all booked seats
    void displayBookedSeats()
    {
        cout << "Booked Seats:" << endl;

        Node* current = seatList.getHead();
        while (current)
        {
            cout << "Seat " << current->seatNumber << ": " << current->passengerName << endl;
            current = current->next;
        }

        cout << endl;
    }

    // Display booking queue
    void displayBookingQueue()
    {
        cout << "Booking Queue:" << endl;

        int front = bookingQueue.getFront();
        int rear = bookingQueue.getRear();  // Accessing 'rear' using the public function

        if (front == -1)
        {
            cout << "Booking queue is empty." << endl;
        }
        else
        {
            for (int i = front; i <= rear; ++i)
            {
                cout << "Seat " << bookingQueue.getQueue()[i] << endl;
            }
        }

        cout << endl;
    }

    // Display the list of passengers
    void displayPassengersList() const
    {
        cout << "Passengers List:" << endl;

        Node* current = seatList.getHead();
        while (current)
        {
            cout << "Seat " << current->seatNumber << ": " << current->passengerName << endl;
            current = current->next;
        }

        cout << endl;
    }

   // Upgrade the seat to a higher class
    void upgradeSeat(int seat)
    {
        Node* current = seatList.getHead();

        // Find the seat in the linked list
        while (current)
        {
            if (current->seatNumber == seat)
            {
                // Upgrade the seat class using if-else statements
                if (current->seatClass == SeatClass::ECONOMY)
                {
                    current->seatClass = SeatClass::BUSINESS;
                    cout << "Seat " << seat << " upgraded to Business class." << endl;
                }
                else if (current->seatClass == SeatClass::BUSINESS)
                {
                    current->seatClass = SeatClass::FIRST_CLASS;
                    cout << "Seat " << seat << " upgraded to First Class." << endl;
                }
                else
                {
                    cout << "Seat " << seat << " is already in the highest class." << endl;
                }

                return;
            }

            current = current->next;
        }

        // If the seat is not found
        cout << "Seat " << seat << " not found. Cannot upgrade." << endl;
    }

    // Downgrade the seat to a lower class
    void downgradeSeat(int seat)
    {
        Node* current = seatList.getHead();

        // Find the seat in the linked list
        while (current)
        {
            if (current->seatNumber == seat)
            {
                // Downgrade the seat class using if-else statements
                if (current->seatClass == SeatClass::FIRST_CLASS)
                {
                    current->seatClass = SeatClass::BUSINESS;
                    cout << "Seat " << seat << " downgraded to Business class." << endl;
                }
                else if (current->seatClass == SeatClass::BUSINESS)
                {
                    current->seatClass = SeatClass::ECONOMY;
                    cout << "Seat " << seat << " downgraded to Economy class." << endl;
                }
                else
                {
                    cout << "Seat " << seat << " is already in the lowest class." << endl;
                }

                return;
            }

            current = current->next;
        }

        // If the seat is not found
        cout << "Seat " << seat << " not found. Cannot downgrade." << endl;
    }

    // View flight details
    void viewFlightDetails()
    {
        cout << "Flight Details:\n";
        cout << "Flight Number: ABC123\n";
        cout << "Departure: New York\n";
        cout << "Destination: Los Angeles\n";
        cout << "Departure Time: 08:00 AM\n";
        cout << "Arrival Time: 11:00 AM\n";
        cout << "Booked Seats:\n";
        seatList.displayBookedSeats();
    }

    // Change passenger name
    void changePassengerName(int seat, const string& newName)
    {
        Node* current = seatList.getHead();

        // Find the seat in the linked list
        while (current)
        {
            if (current->seatNumber == seat)
            {
                current->passengerName = newName;
                cout << "Passenger name for seat " << seat << " changed to " << newName << "." << endl;
                return;
            }

            current = current->next;
        }

        // If the seat is not found
        cout << "Seat " << seat << " not found. Cannot change passenger name." << endl;
    }

    // Add extra service
    void addExtraService()
    {
        int seatToModify;
        cout << "Enter the seat number to add extra service: ";

        while (!(cin >> seatToModify)) {
            cin.clear();
            cin.ignore(MAX_INPUT, '\n');
            cout << "Invalid input. Please enter a number: ";
        }

        if (isSeatBooked(seatToModify))
        {
            // Add your logic for extra services here
            cout << "Extra service added to seat " << seatToModify << ".\n";
        }
        else
        {
            cout << "Seat " << seatToModify << " is not booked. Cannot add extra service.\n";
        }
    }

    // Display extra services for a specified seat
    void displayExtraServices(int seatToDisplay)
    {
        Node* current = seatList.getHead();

        // Find the seat in the linked list
        while (current)
        {
            if (current->seatNumber == seatToDisplay)
            {
                // Display extra services for the specified seat
                // Add your logic for displaying extra services here
                cout << "Extra services for seat " << seatToDisplay << ":\n";
                cout << "- Extra Service 1\n";
                cout << "- Extra Service 2\n";
                // ...

                return;
            }

            current = current->next;
        }

        // If the seat is not found
        cout << "Seat " << seatToDisplay << " not found. Cannot display extra services.\n";
    }

    // Remove extra service for a specified seat
    void removeExtraService(int seat)
    {
        Node* current = seatList.getHead();

        // Find the seat in the linked list
        while (current)
        {
            if (current->seatNumber == seat)
            {
                // Remove the extra service
                // Add your logic for removing extra service here
                cout << "Extra service removed for seat " << seat << "." << endl;
                return;
            }

            current = current->next;
        }

        // If the seat is not found
        cout << "Seat " << seat << " not found. Cannot remove extra service." << endl;
    }

    // Placeholder function for calculate total revenue
    void calculateTotalRevenue()
    {
        const int ECONOMY_PRICE = 100;
        const int BUSINESS_PRICE = 200;
        const int FIRST_CLASS_PRICE = 300;

        int totalRevenue = 0;

        Node* current = seatList.getHead();

        while (current)
        {
            // Add the price of each booked seat to the total revenue
            switch (current->seatClass)
            {
            case SeatClass::ECONOMY:
                totalRevenue += ECONOMY_PRICE;
                break;
            case SeatClass::BUSINESS:
                totalRevenue += BUSINESS_PRICE;
                break;
            case SeatClass::FIRST_CLASS:
                totalRevenue += FIRST_CLASS_PRICE;
                break;
            }

            current = current->next;
        }

        cout << "Total revenue: $" << totalRevenue << endl;
    }

    // Placeholder function for print boarding pass
    void printBoardingPass(int seatToPrintPass)
    {
        Node* current = seatList.getHead();

        while (current)
        {
            if (current->seatNumber == seatToPrintPass)
            {
                // Print boarding pass details
                cout << "Boarding Pass for Seat " << current->seatNumber << ":\n";
                cout << "Passenger Name: " << current->passengerName << "\n";
                cout << "Seat Class: ";
                switch (current->seatClass)
                {
                case SeatClass::ECONOMY:
                    cout << "Economy\n";
                    break;
                case SeatClass::BUSINESS:
                    cout << "Business\n";
                    break;
                case SeatClass::FIRST_CLASS:
                    cout << "First Class\n";
                    break;
                }

                // Add more details if needed

                cout << "Printed successfully.\n";
                return;
            }

            current = current->next;
        }

        cout << "Seat " << seatToPrintPass << " not found. Boarding pass not printed.\n";
    }

    // Placeholder function for save data
    void saveData()
    {
        ofstream outputFile("booked_seats.txt");

        if (outputFile.is_open())
        {
            Node* current = seatList.getHead();

            while (current)
            {
                // Save seat details to the file
                outputFile << "Seat Number: " << current->seatNumber << "\n";
                outputFile << "Passenger Name: " << current->passengerName << "\n";
                outputFile << "Seat Class: ";
                switch (current->seatClass)
                {
                case SeatClass::ECONOMY:
                    outputFile << "Economy\n";
                    break;
                case SeatClass::BUSINESS:
                    outputFile << "Business\n";
                    break;
                case SeatClass::FIRST_CLASS:
                    outputFile << "First Class\n";
                    break;
                }

                outputFile << "\n";

                current = current->next;
            }

            cout << "Data saved successfully.\n";
            outputFile.close();
        }
        else
        {
            cout << "Unable to open the file for saving data.\n";
        }
    }
};


// Display the main menu of the Airline Reservation System
void displayMenu()
{
    cout << "\nAirline Reservation System Menu:\n";
    cout << "1. Display Available Seats\n";
    cout << "2. Request Booking\n";
    cout << "3. Book Seat\n";
    cout << "4. Undo Last Booking\n";
    cout << "5. Display Booked Seats\n";
    cout << "6. Display Booking Queue\n";
    cout << "7. Check Seat Availability\n";
    cout << "8. Cancel Booking\n";
    cout << "9. Display Passengers List\n";
    cout << "10. Upgrade Seat\n";
    cout << "11. Downgrade Seat\n";
    cout << "12. View Flight Details\n";
    cout << "13. Change Passenger Name\n";
    cout << "14. Add Extra Service\n";
    cout << "15. Display Extra Services\n";
    cout << "16. Remove Extra Service\n";
    cout << "17. Calculate Total Revenue\n";
    cout << "18. Print Boarding Pass\n";
    cout << "19. Save Data\n";
    cout << "20. Exit\n";
    cout << "Enter your choice: ";
}
int main() {
    AirlineReservationSystem airlineSystem;

    int choice;
    do {
        displayMenu();

        while (!(cin >> choice)) {
            cin.clear();
            cin.ignore(MAX_INPUT, '\n');
            cout << "Invalid input. Please enter a number: ";
        }

        if (choice == 1) {
            airlineSystem.displayAvailableSeats();
        } else if (choice == 2) {
            int seatToRequest;
            cout << "Enter the seat number to request booking: ";
            while (!(cin >> seatToRequest)) {
                cin.clear();
                cin.ignore(MAX_INPUT, '\n');
                cout << "Invalid input. Please enter a number: ";
            }
            airlineSystem.requestBooking(seatToRequest);
        } else if (choice == 3) {
            string passengerName;
            cout << "Enter passenger name: ";
            cin.ignore();
            getline(cin, passengerName);
            airlineSystem.bookSeat(passengerName);
        } else if (choice == 4) {
            airlineSystem.undoLastBooking();
        } else if (choice == 5) {
            airlineSystem.displayBookedSeats();
        } else if (choice == 6) {
            airlineSystem.displayBookingQueue();
        } else if (choice == 7) {
            // Add case for checking seat availability
        } else if (choice == 8) {
            int seatToCancel;
            cout << "Enter the seat number to cancel booking: ";
            while (!(cin >> seatToCancel)) {
                cin.clear();
                cin.ignore(MAX_INPUT, '\n');
                cout << "Invalid input. Please enter a number: ";
            }
            airlineSystem.cancelBooking(seatToCancel);
        } else if (choice == 9) {
            airlineSystem.displayPassengersList();
        } else if (choice == 10) {
            int seatToUpgrade;
            cout << "Enter the seat number to upgrade: ";
            while (!(cin >> seatToUpgrade)) {
                cin.clear();
                cin.ignore(MAX_INPUT, '\n');
                cout << "Invalid input. Please enter a number: ";
            }
            airlineSystem.upgradeSeat(seatToUpgrade);
        } else if (choice == 20) {
            cout << "Exiting the Airline Reservation System. Goodbye!\n";
        } else {
            cout << "Invalid choice. Please enter a valid option.\n";
        }

    } while (choice != 20);

    return 0;
}
